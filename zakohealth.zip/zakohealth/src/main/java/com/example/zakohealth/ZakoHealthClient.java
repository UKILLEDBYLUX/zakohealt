package com.example.zakohealth;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;

public class ZakoHealthClient implements ClientModInitializer {
    /** Health is detected only for players closer than this (blocks). */
    private static final double RANGE = 5.0;

    /** How long (ms) the last seen health stays on screen after you look away. */
    private static final long HOLD_MS = 3000;
    /** The last part of HOLD_MS during which the number fades out. */
    private static final long FADE_MS = 500;

    /** Gap (px) between the crosshair center and the number. */
    private static final int Y_OFFSET = 10;

    private static final int COLOR_HIGH = 0x55FF55;       // green
    private static final int COLOR_MID = 0xFFAA00;        // orange
    private static final int COLOR_LOW = 0xFF5555;        // red
    private static final int COLOR_ABSORPTION = 0xFFD700; // gold
    private static final float MID_THRESHOLD = 0.60f;     // below this: orange
    private static final float LOW_THRESHOLD = 0.30f;     // below this: red

    // Last seen player's health (snapshot)
    private static boolean hasSnapshot = false;
    private static float snapHealth;
    private static float snapMax;
    private static float snapAbsorption;
    private static long snapTimeMs;

    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register(ZakoHealthClient::render);
    }

    /** Returns the player under the crosshair within RANGE, or null. Only players count. */
    private static PlayerEntity findTarget(MinecraftClient client, float delta) {
        Entity cam = client.getCameraEntity();
        if (cam == null || client.world == null) return null;

        Vec3d start = cam.getCameraPosVec(delta);
        Vec3d dir = cam.getRotationVec(delta);
        Vec3d end = start.add(dir.multiply(RANGE));

        // Don't "see" through walls: limit the search by the first block hit.
        HitResult blockHit = cam.raycast(RANGE, delta, false);
        double maxDistSq = blockHit.getType() == HitResult.Type.MISS
                ? RANGE * RANGE
                : blockHit.getPos().squaredDistanceTo(start);

        Box box = cam.getBoundingBox().stretch(dir.multiply(RANGE)).expand(1.0);
        EntityHitResult hit = ProjectileUtil.raycast(
                cam, start, end, box,
                e -> e instanceof PlayerEntity && !e.isSpectator() && e.canHit(),
                maxDistSq);

        if (hit != null && hit.getEntity() instanceof PlayerEntity player && player.isAlive()) {
            return player;
        }
        return null;
    }

    private static int colorFor(float ratio) {
        if (ratio < LOW_THRESHOLD) return COLOR_LOW;
        if (ratio < MID_THRESHOLD) return COLOR_MID;
        return COLOR_HIGH;
    }

    private static int withAlpha(int rgb, int alpha) {
        return (alpha << 24) | (rgb & 0xFFFFFF);
    }

    /** 20 -> "20", 18.5 -> "18.5" */
    private static String fmt(float v) {
        if (Math.abs(v - Math.round(v)) < 0.05f) return String.valueOf(Math.round(v));
        return String.format(Locale.ROOT, "%.1f", v);
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            hasSnapshot = false;
            return;
        }
        if (client.options.hudHidden || client.currentScreen != null) return;

        long now = System.currentTimeMillis();
        float delta = tickCounter.getTickDelta(true);

        PlayerEntity target = findTarget(client, delta);
        if (target != null) {
            // Exact values: health and absorption are synced entity data. Max health is the
            // synced attribute, so bonus HP from held/worn items is already included.
            snapHealth = target.getHealth();
            snapMax = Math.max(target.getMaxHealth(), 0.0001f);
            snapAbsorption = target.getAbsorptionAmount();
            snapTimeMs = now;
            hasSnapshot = true;
        }

        if (!hasSnapshot) return;
        long age = now - snapTimeMs;
        if (age > HOLD_MS) {
            hasSnapshot = false;
            return;
        }

        int alpha = age <= HOLD_MS - FADE_MS
                ? 255
                : (int) (255L * (HOLD_MS - age) / FADE_MS);
        if (alpha < 8) return;

        float ratio = MathHelper.clamp(snapHealth / snapMax, 0f, 1f);

        TextRenderer font = client.textRenderer;
        Text healthText = Text.literal(fmt(snapHealth));
        Text absText = snapAbsorption > 0f ? Text.literal("+" + fmt(snapAbsorption)) : null;

        int healthW = font.getWidth(healthText);
        int gap = 3;
        int totalW = healthW + (absText != null ? gap + font.getWidth(absText) : 0);

        int x = ctx.getScaledWindowWidth() / 2 - totalW / 2;
        int y = ctx.getScaledWindowHeight() / 2 + Y_OFFSET;

        ctx.drawTextWithShadow(font, healthText, x, y, withAlpha(colorFor(ratio), alpha));
        if (absText != null) {
            ctx.drawTextWithShadow(font, absText, x + healthW + gap, y, withAlpha(COLOR_ABSORPTION, alpha));
        }
    }
}
